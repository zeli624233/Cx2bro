﻿#include "Application.h"
#include "path.h"
#include "util.h"
#include "ExtendUtils.h"

namespace Engine
{
    /// <summary>
    /// 单实例
    /// </summary>
    static Application* g_Instance = nullptr;

    //Hook插件功能
    tTVPV2LinkProc g_V2Link = nullptr;
    HRESULT __stdcall HookV2Link(iTVPFunctionExporter* exporter)
    {
        HRESULT result = g_V2Link(exporter);
        HookUtils::InlineHook::UnHook(g_V2Link, HookV2Link);
        g_V2Link = nullptr;

        //初始化插件
        Application::GetInstance()->InitializeTVPEngine(exporter);

        return result;
    }

    //———— 改用 Hook LoadLibraryW 代替 Hook GetProcAddress ————
    // 汉化补丁（version.dll）常 Hook GetProcAddress 来拦截游戏启动，
    // 我们的 Dumper 也 Hook GetProcAddress 会导致 Detours 链冲突，进程崩溃。
    // Hook LoadLibraryW 完全绕过这个冲突：汉化补丁不会碰 LoadLibraryW，
    // 我们在这里拦截插件加载，找到 V2Link 后再 Hook 它。
    auto g_OriginalLoadLibraryW = ::LoadLibraryW;
    HMODULE WINAPI HookLoadLibraryW(LPCWSTR lpLibFileName)
    {
        HMODULE result = g_OriginalLoadLibraryW(lpLibFileName);
        if (!result) return result;

        // 忽略 NULL 路径（序号加载等）
        if (HIWORD(lpLibFileName) == 0)
            return result;

        // 避免处理自己
        if (wcsstr(lpLibFileName, L"CxdecStringDumper") != nullptr ||
            wcsstr(lpLibFileName, L"cXdecStringDumper") != nullptr)
            return result;

        // 检查加载的 DLL 是否导出 V2Link
        FARPROC v2Link = ::GetProcAddress(result, "V2Link");
        if (!v2Link)
            return result;

        // 已初始化过则跳过
        Application* app = Application::GetInstance();
        if (!app || app->IsTVPEngineInitialize())
            return result;

        // 获取该模块的代码段（用于后续特征码搜索 CreateCompoundStorageMedia）
        PIMAGE_DOS_HEADER dosHeader = (PIMAGE_DOS_HEADER)result;
        PIMAGE_NT_HEADERS ntHeader = PIMAGE_NT_HEADERS((ULONG_PTR)result + dosHeader->e_lfanew);
        DWORD optionalHeaderSize = ntHeader->FileHeader.SizeOfOptionalHeader;
        PIMAGE_SECTION_HEADER codeSectionHeader = (PIMAGE_SECTION_HEADER)(
            (ULONG_PTR)ntHeader + sizeof(ntHeader->Signature) + sizeof(IMAGE_FILE_HEADER) + optionalHeaderSize);

        // 第一个节通常是代码段（.text）
        DWORD codeStartRva = codeSectionHeader->VirtualAddress;
        DWORD codeSize = codeSectionHeader->SizeOfRawData;
        ULONG_PTR codeStartVa = (ULONG_PTR)result + codeStartRva;

        // Hook V2Link，这样游戏调用它初始化插件时我们会收到回调
        g_V2Link = (tTVPV2LinkProc)v2Link;
        HookUtils::InlineHook::Hook(g_V2Link, HookV2Link);

        // 初始化 StringDumper：用特征码搜索 CreateCompoundStorageMedia
        HashCore* dumper = app->GetStringDumper();
        if (!dumper->IsInitialized())
        {
            dumper->Initialize((PVOID)codeStartVa, codeSize);
        }

        return result;
    }


    //**********Application***********//
    Application::Application()
    {
        this->mCurrentDirectoryPath = Path::GetDirectoryName(Util::GetModulePathW(::GetModuleHandleW(NULL)));
        wchar_t outputRoot[MAX_PATH]{};
        if (::GetEnvironmentVariableW(L"CXDEC_OUTPUT_ROOT", outputRoot, MAX_PATH) > 0)
        {
            this->mCurrentDirectoryPath = outputRoot;
        }
        this->mTVPExporterInitialized = false;

        //单例Dumper
        this->mStringDumper = HashCore::GetInstance();

        // 设置 Hash 输出路径。新版工作台通过 CXDEC_OUTPUT_ROOT 指向 User\N 工作区。
        this->mStringDumper->SetOutputDirectory(this->mCurrentDirectoryPath);
    }

    Application::~Application()
    {
        if (this->mStringDumper)
        {
            //单例Dumper释放
            HashCore::Release();
            this->mStringDumper = nullptr;
        }
    }

    void Application::InitializeModule(HMODULE hModule)
    {
        this->mModuleDirectoryPath = Path::GetDirectoryName(Util::GetModulePathW(hModule));
    }

    void Application::InitializeTVPEngine(iTVPFunctionExporter* exporter)
    {
        this->mTVPExporterInitialized = TVPInitImportStub(exporter);
        TVPSetCommandLine(L"-debugwin", L"yes");
    }

    bool Application::IsTVPEngineInitialize()
    {
        return this->mTVPExporterInitialized;
    }

    HashCore* Application::GetStringDumper()
    {
        return this->mStringDumper;
    }

    //********====Static====********//

    Application* Application::GetInstance()
    {
        return g_Instance;
    }

    void Application::Initialize(HMODULE hModule)
    {
        g_Instance = new Application();
        g_Instance->InitializeModule(hModule);

        // 改为 Hook LoadLibraryW（不碰 GetProcAddress，避免与汉化补丁冲突）
        HookUtils::InlineHook::Hook(g_OriginalLoadLibraryW, HookLoadLibraryW);
    }

    void Application::Release()
    {
        if (g_Instance)
        {
            delete g_Instance;
            g_Instance = nullptr;
        }
    }

    //================================//
}

