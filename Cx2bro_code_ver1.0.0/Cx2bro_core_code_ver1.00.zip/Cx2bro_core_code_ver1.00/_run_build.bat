@echo off
chcp 936 >nul
echo ===== Building CxdecDynamicHashCollector =====
cd /d "E:\workbench\gpt5\cxdecv2\CxdecDynamicHashCollector"
call BUILD.bat
echo ===== Exit code: %ERRORLEVEL% =====
pause
