@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

set CXDEC=%~dp0
echo ========================================
echo  Cx2bro 全部项目编译 (静态链接 /MT)
echo ========================================
echo 源码目录: %CXDEC%
echo.

:: ---- 1. CxdecCoreCLI ----
echo [1/4] 编译 CxdecCoreCLI...
cd /d "%CXDEC%CxdecCoreCLI"
call _build_fix.bat
if !ERRORLEVEL! NEQ 0 (
    echo [错误] CxdecCoreCLI 编译失败
    pause & exit /b 1
)
echo [OK] CxdecCoreCLI 编译成功
echo.

:: ---- 2. CxdecDynamicHashCollector ----
echo [2/4] 编译 CxdecDynamicHashCollector...
cd /d "%CXDEC%CxdecDynamicHashCollector"
call BUILD.bat
if !ERRORLEVEL! NEQ 0 (
    echo [错误] CxdecDynamicHashCollector 编译失败
    pause & exit /b 1
)
echo [OK] CxdecDynamicHashCollector 编译成功
echo.

:: ---- 3. 初始化 VS2022 环境 ----
echo [准备] 初始化 VS2022 编译环境...
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars32.bat" >nul 2>&1

:: ---- 4. CxdecExtractor / Loader / UI / KeyDumper / StringDumper ----
echo [3/4] 编译注入式 DLL/EXE (msbuild)... 
cd /d "%CXDEC%"

set MSBUILD_ARGS=/p:Configuration=Release /p:Platform=Win32 /p:SolutionDir=%CXDEC% /t:Build /nologo

echo   -> CxdecExtractor
msbuild CxdecExtractor\CxdecExtractor.vcxproj %MSBUILD_ARGS%
if !ERRORLEVEL! NEQ 0 ( echo [警告] CxdecExtractor 编译失败 & goto :ms_error )

echo   -> CxdecExtractorLoader
msbuild CxdecExtractorLoader\CxdecExtractorLoader.vcxproj %MSBUILD_ARGS%
if !ERRORLEVEL! NEQ 0 ( echo [警告] CxdecExtractorLoader 编译失败 & goto :ms_error )

echo   -> CxdecExtractorUI
msbuild CxdecExtractorUI\CxdecExtractorUI.vcxproj %MSBUILD_ARGS%
if !ERRORLEVEL! NEQ 0 ( echo [警告] CxdecExtractorUI 编译失败 & goto :ms_error )

echo   -> CxdecKeyDumper
msbuild CxdecKeyDumper\CxdecKeyDumper.vcxproj %MSBUILD_ARGS%
if !ERRORLEVEL! NEQ 0 ( echo [警告] CxdecKeyDumper 编译失败 & goto :ms_error )

echo   -> CxdecStringDumper
msbuild CxdecStringDumper\CxdecStringDumper.vcxproj %MSBUILD_ARGS%
if !ERRORLEVEL! NEQ 0 ( echo [警告] CxdecStringDumper 编译失败 & goto :ms_error )

echo [OK] 注入式 DLL/EXE 编译完成
echo.

:: ---- 5. 部署到 core 目录 ----
echo [4/4] 部署编译产物到 core...
set COREDIR=%CXDEC%..\..\CxdecV2ExtractorWorkbench_home_step_feedback_fixed\Source\CxdecV2ExtractorWorkbench\core

echo   -> 创建 core 目录
if not exist "%COREDIR%" mkdir "%COREDIR%"

echo   -> CxdecCoreCLI.exe
copy /Y "%CXDEC%CxdecCoreCLI\Release\CxdecCoreCLI.exe" "%COREDIR%\" >nul

echo   -> CxdecDynamicHashCollector.exe
copy /Y "%CXDEC%CxdecDynamicHashCollector\Release\CxdecDynamicHashCollector.exe" "%COREDIR%\" >nul

echo   -> CxdecExtractor.dll
copy /Y "%CXDEC%CxdecExtractor\Release\CxdecExtractor.dll" "%COREDIR%\" >nul

echo   -> CxdecExtractorLoader.exe
copy /Y "%CXDEC%CxdecExtractorLoader\Release\CxdecExtractorLoader.exe" "%COREDIR%\" >nul

echo   -> CxdecExtractorUI.dll
copy /Y "%CXDEC%CxdecExtractorUI\Release\CxdecExtractorUI.dll" "%COREDIR%\" >nul

echo   -> CxdecKeyDumper.dll
copy /Y "%CXDEC%CxdecKeyDumper\Release\CxdecKeyDumper.dll" "%COREDIR%\" >nul

echo   -> CxdecStringDumper.dll
copy /Y "%CXDEC%CxdecStringDumper\Release\CxdecStringDumper.dll" "%COREDIR%\" >nul

echo.
echo [OK] 全部部署完成！
echo 目标目录: %COREDIR%
echo.

:: ---- 验证产物 ----
echo ========================================
echo  编译产物验证
echo ========================================
for %%f in (
    CxdecCoreCLI.exe
    CxdecDynamicHashCollector.exe
    CxdecExtractor.dll
    CxdecExtractorLoader.exe
    CxdecExtractorUI.dll
    CxdecKeyDumper.dll
    CxdecStringDumper.dll
) do (
    if exist "%COREDIR%\%%f" (
        call :show_size "%COREDIR%\%%f"
    ) else (
        echo   [缺失] %%f
    )
)
echo.
pause
goto :eof

:show_size
    set FILESIZE=%~z1
    set /A FILESIZEKB=FILESIZE/1024
    echo   [OK] %~nx1  (%FILESIZEKB% KB)
    goto :eof

:ms_error
    echo [错误] msbuild 编译失败，请确认 Visual Studio 2022 已安装且组件完整。
    pause & exit /b 1
