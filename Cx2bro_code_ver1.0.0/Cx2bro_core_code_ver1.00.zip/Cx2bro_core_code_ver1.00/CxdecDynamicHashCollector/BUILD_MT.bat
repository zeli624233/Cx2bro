@echo off
chcp 936 >nul
setlocal enabledelayedexpansion

set ROOT=%~dp0
set SRC=%ROOT%src
set OUT=%ROOT%Release
set TARGET=%OUT%\CxdecDynamicHashCollector.exe

if not exist "%OUT%" mkdir "%OUT%"

call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvarsall.bat" x86 >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Failed to initialize VS2022 environment
    pause & exit /b 1
)

set SOURCES=
for /R "%SRC%" %%f in (*.cpp) do set "SOURCES=!SOURCES! "%%f""

echo Compiling with /MT (static CRT)...
cl /nologo /MT /O2 /W3 /EHsc /DUNICODE /D_UNICODE /utf-8 /Fo"%OUT%\\" /Fe"%TARGET%" %SOURCES% /link shell32.lib comctl32.lib comdlg32.lib user32.lib kernel32.lib gdi32.lib advapi32.lib

if errorlevel 1 (
    echo [ERROR] Build failed
    pause & exit /b 1
)

echo [OK] Build succeeded: %TARGET%
echo.
:: Deploy to core
set COREDIR=E:\workbench\gpt5\CxdecV2ExtractorWorkbench_home_step_feedback_fixed\Source\CxdecV2ExtractorWorkbench\core
taskkill /f /im CxdecDynamicHashCollector.exe >nul 2>nul
copy /Y "%TARGET%" "%COREDIR%\" >nul
if exist "%COREDIR%\CxdecDynamicHashCollector.exe" (
    echo [OK] Deployed to core
) else (
    echo [WARN] Deploy failed
)
echo.
pause
